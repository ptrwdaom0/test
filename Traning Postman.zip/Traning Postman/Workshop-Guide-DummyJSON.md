# ขั้นตอนที่ต้องทำ — Workshop: Data-Driven Testing ด้วย Postman (DummyJSON)

ทำตามลำดับ Step 0 → 4

> **หมายเหตุ:** Workshop นี้ปรับมาจาก reqres.in โดยใช้ **dummyjson.com** แทน เพราะไม่ต้องใช้ API key
> (reqres.in ตั้งแต่ปี 2025 เป็นต้นมา endpoint `/api/*` ต้องใส่ header `x-api-key` ถึงจะเรียกได้)

---

## Step 0: Import และเลือก Environment

1. เปิด Postman → **Import** → เลือกไฟล์ `Workshop-DummyJSON.postman_environment.json`
2. เลือก Environment **"Workshop - DummyJSON"** ที่ dropdown มุมขวาบนของหน้าจอ (สำคัญมาก — ทำก่อนไป Step อื่น)
3. เปิดดูตัวแปรใน Environment:
   - `base_url` → มีค่าอยู่แล้ว (`https://dummyjson.com`)
   - `created_user_id` → ว่างไว้ก่อน (จะถูกเติมค่าอัตโนมัติใน Step 3)

---

## Step 1: สร้างไฟล์ CSV ของตัวเอง

- ดู `my_users_dummyjson.csv` เป็นตัวอย่างโครงสร้าง — มีคอลัมน์: `firstName`, `lastName`, `age`, `lookup_id`, `expected_status`
- สร้างไฟล์ CSV ของตัวเอง 4–6 แถว
- ต้องมีอย่างน้อย **1 แถวเป็น negative case** สำหรับ Request ที่ 3 (Verify) — ตั้ง `lookup_id` เป็นตัวเลขที่ไม่มีอยู่จริงในระบบ (เช่น `9999`) แล้วตั้ง `expected_status = 404`

**ข้อควรระวัง:** ชื่อคอลัมน์ต้องตรงกับที่ Collection ใช้อ้างอิง คือ `firstName`, `lastName`, `age`, `lookup_id`, `expected_status` เป๊ะๆ — ถ้าตั้งชื่อคอลัมน์ต่างไป จะต้องไปแก้ Body/URL เองใน Step 2

### ทำไมต้องมี `lookup_id` แยกจาก `created_user_id`?

DummyJSON เป็น mock API — endpoint `POST /users/add` **ไม่ได้ validate ข้อมูลจริง** และไม่บันทึกข้อมูลลง server เลย ต่อให้ส่ง `firstName` เป็นค่าว่าง ระบบก็จะตอบ `201 Created` เสมอ (ต่างจากระบบจริงที่ต้อง validate field required)

ดังนั้นถ้าจะสาธิต **Negative Test Case** (คาดหวัง error) ให้ควบคุมผลลัพธ์ได้แน่นอน เราจึงใช้ Request ที่ 3 (GET Verify) ยิงด้วย `lookup_id` ที่กำหนดเองจาก CSV โดยตรงแทน:
- `lookup_id` ที่มีอยู่จริงในชุดข้อมูล (1–208) → ได้ `200 OK`
- `lookup_id` ที่ไม่มีอยู่จริง (เช่น `9999`) → ได้ `404 Not Found`

---

## Step 2: Import Collection และทำความเข้าใจ Mapping

1. Import ไฟล์ `Bulk_User_Creation_Test_DummyJSON.postman_collection.json`
2. เปิด Request **"2. POST - Create User"** — สังเกตว่า Body อ้างอิงตัวแปรจาก CSV โดยตรงอยู่แล้ว (`{{firstName}}`, `{{lastName}}`, `{{age}}`) ไม่ต้องแก้อะไรถ้าใช้ชื่อคอลัมน์ตรงตาม Step 1

---

## Step 2.5: ทำความเข้าใจ GET Pre-check และ Post-check

1. เปิด Request **"1. GET - List Users"** แล้วกด Send เดี่ยวๆ ก่อน (ยังไม่ต้องผ่าน Runner) — ดู Response structure (`users`, `total`, `skip`, `limit`) และสังเกต Query Parameter `?limit=5`
2. เปิด Request **"3. GET - Verify User by Lookup ID"** สังเกตว่า URL ใช้ `{{lookup_id}}` — ค่านี้มาจากคอลัมน์ใน CSV โดยตรง **ไม่ใช่** ค่าที่ POST เซ็ตให้ (ต่างจาก workshop เดิมที่ใช้ reqres.in)
3. สังเกตว่า Request "2. POST - Create User" ก็ยังเก็บ `created_user_id` ไว้ใน Environment เหมือนเดิม (`pm.environment.set(...)`) เพื่อให้เห็น pattern "ส่งค่าระหว่าง Request" — แต่ Request 3 ในเวอร์ชันนี้ไม่ได้เอาค่านั้นมาใช้ต่อ เพราะ id ที่ได้จาก POST เป็นของจำลอง (ไม่มีอยู่จริงในระบบ ถ้าเอาไป GET จะได้ 404 เสมอ ไม่ว่าจะส่งข้อมูลถูกหรือผิด — ไม่เหมาะเอามาทำ Positive/Negative case ที่ควบคุมได้)

---

## Step 3: ทำความเข้าใจและต่อยอด Test Script

เปิด Tab **"Tests"** ของ Request **"2. POST - Create User"** อ่านทำความเข้าใจทีละส่วน:

- เช็คว่า status code เป็น `201` เสมอ (เพราะ DummyJSON ไม่ validate input)
- เช็คว่า response มี field `id`

### โจทย์ที่ 1

เขียน assertion เพิ่มเอง เพื่อเช็คว่าค่า `firstName` และ `lastName` ที่ได้กลับมาใน Response ตรงกับค่าที่ส่งไปจาก CSV หรือไม่

**Hint:**
- ค่าที่ได้จาก Response → ใช้ `jsonData.firstName` และ `jsonData.lastName`
- ค่าที่ควรจะเป็น (ดึงจาก CSV) → ใช้ `pm.iterationData.get("firstName")` และ `pm.iterationData.get("lastName")`

เขียนโค้ดต่อจาก `// TODO (โจทย์)` ในไฟล์ Collection (อย่าลืมว่าต้องอยู่หลังบรรทัดที่เก็บ `jsonData` แล้ว)

### โจทย์ที่ 2 (โบนัส)

เปิด Tab "Tests" ของ Request **"3. GET - Verify User by Lookup ID"** — ลองเพิ่ม test ตรวจสอบว่าเมื่อ `expected_status` เป็น `404` แล้ว response body มี property `message` อยู่ด้วยหรือไม่ (DummyJSON จะส่ง `{"message": "User with id '9999' not found"}` กลับมา)

---

## Step 4: รันผ่าน Collection Runner

1. เปิด **Collection Runner** → เลือก Collection **"Bulk User Creation Test (DummyJSON)"**
2. **Select File** → เลือกไฟล์ CSV ของตัวเอง ที่สร้างไว้ใน Step 1 (ไม่ใช่ `my_users_dummyjson.csv` ตัวอย่าง)
3. **Iterations** จะขึ้นอัตโนมัติตามจำนวนแถวใน CSV
4. กด **Run** แล้วอ่านผลลัพธ์ทีละแถว — สังเกตแถว negative case (`lookup_id = 9999`) เป็นพิเศษว่าผลตรงกับที่คาดไว้ (`404`) ไหม

### สรุปพฤติกรรมที่ควรสังเกต

| Request | พฤติกรรมที่คาดหวัง | หมายเหตุ |
|---|---|---|
| 1. GET List Users | `200` เสมอ | ไม่ data-driven |
| 2. POST Create User | `201` เสมอ ทุกแถว แม้ `firstName` จะว่าง | เพราะเป็น mock API ไม่ validate |
| 3. GET Verify by lookup_id | `200` หรือ `404` ตามที่ CSV กำหนด | นี่คือจุดที่ฝึก Positive/Negative test จริง |

---

**ประเด็นสำคัญสำหรับผู้เข้าอบรม:** Mock API แต่ละตัวมีพฤติกรรมไม่เหมือนกัน (บาง API validate input บาง API ไม่ validate) — ก่อนออกแบบ Test Case ต้องอ่านพฤติกรรมจริงของ API ก่อนเสมอ ไม่ใช่ assume ว่าทุก API จะตอบ error เมื่อได้รับ input ที่ไม่ถูกต้อง
