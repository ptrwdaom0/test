# Workshop: ทดสอบ API ที่มีเงื่อนไขซับซ้อนขึ้น (Duplicate Email + Job Whitelist)

ทำตามลำดับ Step 1 → 7 ห้ามข้าม

---

## Step 1: สร้าง Mock Server

1. Import ไฟล์ `Workshop-Mock-API-Advanced.postman_collection.json`
2. Sidebar ซ้าย → **Mock Servers** → **Create mock server**
   (หรือคลิกขวาที่ Collection ที่เพิ่ง import → **Mock collection** ก็ได้ เร็วกว่า)
3. เลือก Collection **"Workshop Mock API - Advanced"**
4. ตั้งชื่ออะไรก็ได้ เช่น `Workshop Mock Advanced` → กด **Create**
5. จะได้ URL แบบ `https://xxxx.mock.pstmn.io` มา → **copy เก็บไว้**

---

## Step 2: ตั้งค่า Environment

1. Import ไฟล์ `Workshop-MockServer-Advanced.postman_environment.json`
2. เลือก Environment **"Workshop - Mock Server Advanced"** ที่ dropdown มุมขวาบน
3. เปิด Environment → แก้ค่า `base_url` เป็น URL ที่ copy มาจาก Step 1 → Save

---

## Step 3: ยิง Setup 2 ตัวนี้ก่อน (ยิงทีละอันเอง ยังไม่ต้องใช้ Runner)

1. เปิด request **"0. POST - Reset Workshop State"** → กด **Send**
2. เปิด request **"0b. GET - Job Titles"** → กด **Send**
3. เปิด Environment ขึ้นมาดู → จะเห็นตัวแปร `allowedJobs` มีค่าขึ้นมาแล้ว (list ของ job ที่ใช้ได้)
4. **จดหรือถ่ายรูปค่านี้ไว้** — จะต้องใช้ตอนทำ CSV ใน Step 5

> ทำไมต้องยิง 2 ตัวนี้ก่อน: request `1. POST - Create User` จะเช็คว่า job ที่ส่งไปอยู่ใน list นี้ไหม ถ้ายังไม่เคยยิง `0b` เลย list จะว่าง แล้วทุกแถวจะโดนตัดว่า job ผิดหมด

---

## Step 4: ทำความเข้าใจว่าทำไมต้องเรียงแถว CSV ให้ถูก

request `1. POST - Create User` จะเช็ค email ที่ส่งไปด้วยว่าเคยสร้างสำเร็จไปแล้วหรือยัง (ระบบจำไว้ในตัวแปร `usedEmails`)

- ถ้า email **ไม่เคยเจอมาก่อน** และ job อยู่ใน whitelist → ได้ `201` (สำเร็จ) แล้วระบบจะจำ email นี้ไว้
- ถ้า email **เคยสร้างสำเร็จไปแล้ว** (ในแถวก่อนหน้าของไฟล์เดียวกัน) → ได้ `500` (ซ้ำ — บั๊กจำลองว่า backend โยน error ผิดประเภท)

พูดง่ายๆ คือ ถ้าจะทำแถวที่ตั้งใจให้ error 500 ต้องวางไว้ **หลัง** แถวที่ใช้ email เดียวกันและตั้งใจให้ผ่าน (201) ไปแล้วเท่านั้น สลับที่กันไม่ได้

---

## Step 5: ทำไฟล์ CSV ของตัวเอง

คอลัมน์ที่ต้องมี: `name`, `job`, `email`

ทำ 5-6 แถว ให้ครบทั้ง 3 แบบนี้ อย่างน้อยแบบละ 1 แถว:

1. **สร้างสำเร็จ** — ใช้ job ที่อยู่ใน list จาก Step 3, email ที่ไม่ซ้ำกับแถวไหนเลย → คาดว่าจะได้ `201`
2. **Job ผิด** — ใช้ job ที่**ไม่อยู่**ใน list จาก Step 3 → คาดว่าจะได้ `400`
3. **Email ซ้ำ** — ใช้ email เดียวกับแถวที่ 1 (แถวที่ตั้งใจให้ผ่านไปแล้ว) แต่วางไว้เป็นแถวหลังจากแถวนั้น → คาดว่าจะได้ `500`

ดูตัวอย่างจาก `my_users_advanced.csv` ได้ แต่ให้ทำไฟล์ของตัวเองแยกต่างหาก

---

## Step 6: รันผ่าน Collection Runner

1. เปิด **Collection Runner**
2. เลือก Collection **"Workshop Mock API - Advanced"**
3. **ติ๊กเลือกแค่ request "1. POST - Create User" ตัวเดียว** (ไม่เอา 0, 0b, 2 — พวกนั้นทำไปแล้วใน Step 3)
4. **Select File** → เลือกไฟล์ CSV ที่ทำไว้ใน Step 5
5. กด **Run**
6. เช็คผลทีละแถว ว่าตรงกับที่คาดไว้ในตารางของ Step 5 ไหม

**ถ้าผลไม่ตรง** ลองเช็คตามนี้:
- `allowedJobs` ใน Environment มีค่าไหม (อาจลืมยิง Step 3)
- สะกดชื่อ job ในไฟล์ CSV ตรงกับใน `allowedJobs` เป๊ะไหม (ตัวพิมพ์เล็ก-ใหญ่มีผล)
- แถวที่ตั้งใจให้ error 500 อยู่**หลัง**แถวที่ email เดียวกันสำเร็จไปแล้วจริงไหม

---

> เกร็ดเล็กน้อย: จริงๆ แล้ว duplicate email ควรตอบ `409 Conflict` มากกว่า `500` (ตามที่เคยคุยกันเรื่อง status code ควรเลือกยังไง) — ที่ตั้งใจใช้ `500` ใน workshop นี้เพื่อจำลองสถานการณ์ backend ที่ไม่ได้ validate ให้ถูกต้อง แล้วโยน exception ตรงๆ ออกมาเป็น 500 แทน ใช้เป็นจุดพูดคุยตอนอบรมได้ว่าทำไม 500 ในเคสนี้ถือเป็นบั๊กที่ควรรายงาน ไม่ใช่พฤติกรรมที่ถูกต้อง

## Step 7: โจทย์เพิ่มเติม

เปิด Tab **Tests** ของ request `1. POST - Create User`

**โจทย์ที่ 1**
เวลา status เป็น `500` ให้เขียน assertion เช็คว่า response มี field `error` และข้อความมีคำว่า `mail` อยู่ด้วย

```js
const jsonData = pm.response.json();
pm.expect(jsonData.error).to.include("mail");
```
เขียนต่อจากบรรทัด `// TODO (โจทย์ที่ 1)` ในสคริปต์

**โจทย์ที่ 2**
1. เปิด request เดิม → dropdown **Examples** มุมขวาบน → เลือก **"Invalid job"**
2. แก้ Body เพิ่ม field `allowedJobs` เข้าไป:
   ```json
   {
     "error": "Job 'Data Scientist' is not in the allowed list.",
     "allowedJobs": ["Developer", "QA Engineer", "Business Analyst", "Product Owner"]
   }
   ```
3. Save
4. กลับไป Tab Tests → เขียน assertion เพิ่ม เช็คว่าเมื่อ status เป็น `400` response มี field `allowedJobs` เป็น array

---

## สรุปสั้นๆ ว่าทำไมต้องทำแบบนี้

รอบนี้ไม่มีคอลัมน์ `expected_status` ให้ดูตรงๆ เหมือนรอบก่อน เพราะอยากให้ฝึกคิดเองว่า:
- บาง test ต้องมี "ขั้นเตรียมการ" ก่อนถึงจะรันได้ (ดึง reference data)
- ผลของ request หนึ่ง อาจขึ้นกับ request ก่อนหน้า ต้องคิดเรื่องลำดับ
- ก่อนออกแบบ test case ต้องเข้าใจกฎจริงของระบบก่อน ไม่ใช่เดาเอาเอง
