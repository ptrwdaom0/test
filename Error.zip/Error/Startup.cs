﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CoreUnitOfWork.Statics;
using Easybuy.WebApplication.Core.AspNetCore.Filters;
using Easybuy.WebApplication.CoreUnitOfWork.AspNetCore;
using Easybuy.WebApplication.CoreUnitOfWork.Router;
using Easybuy.WebApplication.CoreUnitOfWork.Services;
using Easybuy.WebApplication.CoreUnitOfWork.Services.Interfaces;
using Easybuy.WebApplication.RLScreen.RLAPI.Caches;
using Easybuy.WebApplication.RLScreen.RLAPI.DataAccess.RLAPIDb;
using Easybuy.WebApplication.RLScreen.RLAPI.DataAccess.RLLogDb;
using Easybuy.WebApplication.RLScreen.RLAPI.Services;
using Easybuy.WebApplication.RLScreen.RLAPI.Services.Interfaces;
using Easybuy.WebApplication.RLScreen.RLAPI.Services.Interfaces.MicroServices;
using Easybuy.WebApplication.RLScreen.RLAPI.Services.MicroService;
using Easybuy.WebApplication.RLScreen.RLAPI.Services.MicroServices;
using Easybuy.WebApplication.Utility.Middleware;
using Easybuy.WebApplication.Utility.Models;
using Easybuy.WebApplication.Utility.StartUp.Filters;
using Easybuy.WebApplication.Utility.UserPrinciple;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using Serilog;

namespace RLAPI
{
    public class Startup
    {
        private readonly string _dbName;
        private readonly string _userName = Environment.GetEnvironmentVariable("RLSCREENDB_MSSQL_USERNAME");
        private readonly string _passWord = Environment.GetEnvironmentVariable("RLSCREENDB_MSSQL_PASSWORD");
        private readonly string _dataSource = Environment.GetEnvironmentVariable("RLSCREENDB_MSSQL_DATASOURCENAME");
        private readonly string _connectionString = Environment.GetEnvironmentVariable("RLSCREENDB_MSSQL_CONNECTIONSTRING");
        private readonly string _dbStringConnection;

        private readonly string _dbNameMy;
        private readonly string _userNameMy = Environment.GetEnvironmentVariable("RLLOGDB_MYSQL_USERNAME");
        private readonly string _passWordMy = Environment.GetEnvironmentVariable("RLLOGDB_MYSQL_PASSWORD");
        private readonly string _dataSourceMy = Environment.GetEnvironmentVariable("RLLOGDB_MYSQL_DATASOURCENAME");
        private readonly string _connectionStringMy = Environment.GetEnvironmentVariable("RLLOGDB_MYSQL_CONNECTIONSTRING");
        private readonly string _dbStringConnectionMy;

        private readonly string _dbNameSagas = Environment.GetEnvironmentVariable("SAGADB_MSSQL_DATABASE");
        private readonly string _userNameSagas = Environment.GetEnvironmentVariable("SAGADB_MSSQL_USERNAME");
        private readonly string _passWordSagas = Environment.GetEnvironmentVariable("SAGADB_MSSQL_PASSWORD");
        private readonly string _dataSourceSagas = Environment.GetEnvironmentVariable("SAGADB_MSSQL_DATASOURCENAME");
        private readonly string _connectionStringSagas = Environment.GetEnvironmentVariable("SAGADB_MSSQL_CONNECTIONSTRING");
        private readonly string _dbStringConnectionSagas;

        private readonly string _aspnetcoreENV = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
        private readonly bool _useMiddleware;


        public Startup(IHostingEnvironment env)
        {
            if (String.IsNullOrEmpty(this._aspnetcoreENV) == true)
            {
                throw new Exception("Not found ASPNETCORE_ENVIRONMENT Variable");
            }

            var builder = new ConfigurationBuilder()
            .SetBasePath(env.ContentRootPath)
            .AddJsonFile($"appsettings.{this._aspnetcoreENV}.json", optional: true, reloadOnChange: true)
            .AddJsonFile("message.json", optional: true, reloadOnChange: true)
            .AddEnvironmentVariables();
            Configuration = builder.Build();

            AppsettingConfigs.config = Configuration;

            string dbNameEnv = Configuration["EnvironmentVariables:ENV_MSSQLDB_NAME"];
            if (String.IsNullOrEmpty(dbNameEnv) == false)
            {
                _dbName = Environment.GetEnvironmentVariable(dbNameEnv);
            }

            var dbNameMyEnv = Configuration["EnvironmentVariables:ENV_MYSQLDB_NAME"];
            if (String.IsNullOrEmpty(dbNameMyEnv) == false)
            {
                _dbNameMy = Environment.GetEnvironmentVariable(dbNameMyEnv);
            }

            List<String> config = new List<string> { _userName, _passWord, _dataSource, _connectionString };

            if (config.All(x => String.IsNullOrEmpty(x) == false))
            {
                this._dbStringConnection = String.Format(_connectionString, _dataSource, _dbName, _userName, _passWord);
            }
            else
            {
                this._dbStringConnection = Configuration.GetConnectionString("RLContext");
            }

            List<String> configMy = new List<string> { _userNameMy, _passWordMy, _dataSourceMy, _connectionStringMy };

            if (configMy.All(x => String.IsNullOrEmpty(x) == false))
            {
                this._dbStringConnectionMy = String.Format(_connectionStringMy, _dataSourceMy, _dbNameMy, _userNameMy, _passWordMy);
            }
            else
            {
                this._dbStringConnectionMy = Configuration.GetConnectionString("RLLog_DB");
            }

            List<String> configSagas = new List<string> { _userNameSagas, _passWordSagas, _dataSourceSagas, _connectionStringSagas };

            if (configSagas.All(x => String.IsNullOrEmpty(x) == false))
            {
                this._dbStringConnectionSagas = String.Format(_connectionStringSagas, _dataSourceSagas, _dbNameSagas, _userNameSagas, _passWordSagas);
            }
            else
            {
                this._dbStringConnectionSagas = Configuration.GetConnectionString("SagasContext");
            }

            SagasDb.strConnection = this._dbStringConnectionSagas;
            
            var rollbackConnection = new List<RollbackConnection>()
            {
                new RollbackConnection()
                {
                    contextName = "RLAPIDbContext",
                    provider = CoreUnitOfWork.Models.Enum.DbProvider.MSSQL,
                    strConn = this._dbStringConnection
                },
                new RollbackConnection()
                {
                    contextName = "RLLogDbContext",
                    provider = CoreUnitOfWork.Models.Enum.DbProvider.MYSQL,
                    strConn = this._dbStringConnectionMy
                }
            };
            SagasDb.rollbackConn = rollbackConnection;

            this._useMiddleware = Configuration.GetSection("Middleware").GetValue<bool>("useMiddleware");

            if (this._useMiddleware == true)
            {
                DateTime dtNow = DateTime.Now;
                var logPath = String.Format(Configuration["Logging:LogPath"], dtNow.ToString("yyyy"), dtNow.ToString("MM"), dtNow.ToString("dd"), dtNow.ToString("HH"));
                Log.Logger = new LoggerConfiguration()
                .WriteTo.ColoredConsole()
                .Enrich.FromLogContext()
                .MinimumLevel.Debug()
                .WriteTo.RollingFile(logPath, shared : true)
                .CreateLogger();
            }
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.Configure<MessageExceptionModel>(options => Configuration.GetSection("MessageExceptionModel").Bind(options));
            services.Configure<MicroServicesModel>(options => Configuration.GetSection("MicroServicesModel").Bind(options));
            services.AddCors(options =>
            {
                options.AddPolicy("CorsPolicy",
                    builder => builder.AllowAnyOrigin()
                      .AllowAnyMethod()
                      .AllowAnyHeader()
                      .AllowCredentials()
                .Build());
            });

            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
            .AddJwtBearer(options =>
            {
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateLifetime = true,
                    ValidateIssuerSigningKey = true,
                    ValidIssuer = Configuration["Jwt:Issuer"],
                    ValidAudience = Configuration["Jwt:Issuer"],
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration["Jwt:Key"]))
                };
            });
            var settings = new JsonSerializerSettings();
            services.AddMvcCore(options =>
            {
                options.Filters.Add(new ProducesAttribute("application/json"));
                options.Filters.Add(new ConsumesAttribute("application/json"));
                options.Filters.Add(typeof(ResponseFilter));
                options.Filters.Add(typeof(UnitOfWorkPoolTransactionFilter));
            })
            .AddApiExplorer()
            .AddFormatterMappings()
            .AddJsonOptions(options => options.SerializerSettings.ContractResolver = new DefaultContractResolver());

            services.AddMemoryCache();

            services.Configure<ApiBehaviorOptions>(options =>
            {
                options.SuppressModelStateInvalidFilter = true;
            });

            services.AddAuthorization(option =>
            {
                option.AddPolicy("RBAC", policy => policy.Requirements.Add(new RBACRequirement()));
            });

            services.AddScoped<IAuthorizationHandler, RBACHandler>();
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            services.AddScoped<UserPrinciple>();
            services.AddScoped<ITransactionPrepareService, TransactionPrepareService>();
            services.AddScoped<ISagasTransactionService, SagasTransactionService>();

            //First Step
            services.AddDbContext<RLLogDbContext>(options =>
            {
                options.UseMySQL(this._dbStringConnectionMy);
                options.EnableSensitiveDataLogging();
            });

            services.AddDbContext<RLAPIDbContext>(options =>
            {
                options.UseSqlServer(this._dbStringConnection);
                options.EnableSensitiveDataLogging();
            });


            // Secound Step
            services.AddUnitOfWorkPool(optionBuilder =>
            {
                optionBuilder.AddUnitOfWork<RLAPIDbContext>(RLAPIUoW.KEY);
                optionBuilder.AddUnitOfWork<RLLogDbContext>(RLLogUoW.KEY);
            });

            // Third Step
            services.AddScoped<IRLAPIUoW, RLAPIUoW>();
            services.AddScoped<IRLLogUoW, RLLogUoW>();


            services.AddScoped<ICustomerTypeService, CustomerTypeService>();
            services.AddScoped<ICompanyTypeService, CompanyTypeService>();
            services.AddScoped<ICheckingService, CheckingService>();
            services.AddScoped<IPendingCodeService, PendingCodeService>();
            services.AddScoped<IDocumentTypeService, DocumentTypeService>();
            services.AddScoped<IWorkProcessUserService, WorkProcessUserService>();
            services.AddScoped<IRLTeamService, RLTeamService>();
            services.AddScoped<IProcessTypeService, ProcessTypeService>();
            services.AddScoped<INotReadyReasonService, NotReadyReasonService>();
            services.AddScoped<IWorkUserStatusHistoryService, WorkUserStatusHistoryService>();
            services.AddScoped<IWorkUserStatusService, WorkUserStatusService>();
            services.AddScoped<ISectionService, SectionService>();
            services.AddScoped<ITeamService, TeamService>();
            services.AddScoped<ILevelService, LevelService>();
            services.AddScoped<IApplicationDetailService, ApplicationDetailService>();
            services.AddScoped<IApplicationPendingService, ApplicationPendingService>();
            services.AddScoped<IApplicationRejectService, ApplicationRejectService>();
            services.AddScoped<IApplicationService, ApplicationService>();
            services.AddScoped<IBotenConfigService, BotenConfigService>();
            services.AddScoped<ICompanyTypeService, CompanyTypeService>();
            services.AddScoped<IConditionSeperateService, ConditionSeperateService>();
            services.AddScoped<IControlDateService, ControlDateService>();
            services.AddScoped<ICustomerRecheckStep1Service, CustomerRecheckStep1Service>();
            services.AddScoped<IKeyInStep1Service, KeyInStep1Service>();
            services.AddScoped<ILoadDataKeyInStep1Service, LoadDataKeyInStep1Service>();
            services.AddScoped<ILoadParameterRecheckStep1Service, LoadParameterRecheckStep1Service>();
            services.AddScoped<IApplicationExtendService, ApplicationExtendService>();
            services.AddScoped<INotReadyReasonService, NotReadyReasonService>();
            services.AddScoped<IParameterListService, ParameterListService>();
            services.AddScoped<IPendingCodeService, PendingCodeService>();
            services.AddScoped<ICheckCriteriaBirthdateService, CheckCriteriaBirthdateService>();
            services.AddScoped<ISaleAgentService, SaleAgentService>();
            services.AddScoped<IVerifyCodeMasterService, VerifyCodeMasterService>();
            services.AddScoped<IVerifyGroupService, VerifyGroupService>();
            services.AddScoped<IVerifyIdentityItemService, VerifyIdentityItemService>();
            services.AddScoped<IGetMasterDataService, GetMasterDataService>();
            services.AddScoped<ISaveApplicationKeyInStep1Service, SaveApplicationKeyInStep1Service>();
            services.AddScoped<ISaveRLKeyInStep1Service, SaveRLKeyInStep1Service>();
            services.AddScoped<IApplicationOnlineService, ApplicationOnlineService>();
            services.AddScoped<IApplicationLogTimeService, ApplicationLogTimeService>();
            services.AddScoped<IApplicationLogTimeHistoryService, ApplicationLogTimeHistoryService>();
            services.AddScoped<ICustomerRecheckStep1MicroService, CustomerRecheckStep1MicroService>();
            services.AddScoped<ISaveRLKeyInStep1MicroService, SaveRLKeyInStep1MicroService>();
            services.AddScoped<ICustomerRecheckStep1MicroService, CustomerRecheckStep1MicroService>();
            services.AddScoped<IGetMasterDataMicroService, GetMasterDataMicroService>();
            services.AddScoped<ICheckCriteriaBirthdateMicroService, CheckCriteriaBirthdateMicroService>();
            services.AddScoped<ILoadParameterRecheckStep1MicroService, LoadParameterRecheckStep1MicroService>();
            services.AddScoped<ISaveApplicationKeyInStep1MicroService, SaveApplicationKeyInStep1MicroService>();
            services.AddScoped<ISaveRLKeyInStep1MicroService, SaveRLKeyInStep1MicroService>();
            services.AddScoped<IVerifyCustomerIdentityService, VerifyCustomerIdentityService>();
            services.AddScoped<IApplicationControlInUseService, ApplicationControlInUseService>();
            services.AddScoped<ICheckAutoRejectService, CheckAutoRejectService>();
            services.AddScoped<ICheckAutoRejectMicroService, CheckAutoRejectMicroService>();
            services.AddScoped<ICheckAutoRejectKeyInStep1Service, CheckAutoRejectKeyInStep1Service>();
            services.AddScoped<ICheckAutoRejectKeyInStep1MicroService, CheckAutoRejectKeyInStep1MicroService>();
            services.AddScoped<ISaveApplicationRejectKeyInStep1Service, SaveApplicationRejectKeyInStep1Service>();
            services.AddScoped<ISaveApplicationRejectKeyInStep1MicroService, SaveApplicationRejectKeyInStep1MicroService>();
            services.AddScoped<ISaveRecheckStep1BeforeReceiveDocumentService, SaveRecheckStep1BeforeReceiveDocumentService>();
            services.AddScoped<ISaveRecheckStep1BeforeReceiveDocumentMicroService, SaveRecheckStep1BeforeReceiveDocumentMicroService>();
            services.AddScoped<ISaveReCheckStep1Service, SaveReCheckStep1Service>();
            services.AddScoped<ISaveReCheckStep1MicroService, SaveReCheckStep1MicroService>();
            services.AddScoped<ICheckReasonAutoRejectService, CheckReasonAutoRejectService>();
            services.AddScoped<ICheckReasonAutoRejectMicroService, CheckReasonAutoRejectMicroService>();
            services.AddScoped<ISaveApplicationOnlineKeyInStep1Service, SaveApplicationOnlineKeyInStep1Service>();
            services.AddScoped<ISaveApplicationOnlineKeyInStep1MicroService, SaveApplicationOnlineKeyInStep1MicroService>();
            services.AddScoped<IVerifyMaillingDataService, VerifyMaillingDataService>();
            services.AddScoped<IVerifyMaillingDataMicroService, VerifyMaillingDataMicroService>();
            services.AddScoped<ISaveVerifyCustomerIdentityService, SaveVerifyCustomerIdentityService>();
            services.AddScoped<ISaveVerifyCustomerIdentityMicroService, SaveVerifyCustomerIdentityMicroService>();
            services.AddScoped<IApplicationOfficeService, ApplicationOfficeService>();
            services.AddScoped<ILoadDataCheckOfficeService, LoadDataCheckOfficeService>();
            services.AddScoped<ICheckMinimumSalaryService, CheckMinimumSalaryService>();
            services.AddScoped<IPrepareDataForVerifyKeyInStep2Service, PrepareDataForVerifyKeyInStep2Service>();
            services.AddScoped<IVerifyKeyInStep1Service, VerifyKeyInStep1Service>();
            services.AddScoped<ISaveApplicationRejectAutoRejectService, SaveApplicationRejectAutoRejectService>();
            services.AddScoped<ISaveAutoRejectCancelCaseService, SaveAutoRejectCancelCaseService>();
            services.AddScoped<IUnLockRecordService, UnLockRecordService>();
            services.AddScoped<ISaveAutoRejectRejectCaseService, SaveAutoRejectRejectCaseService>();
            services.AddScoped<ISaveAutoRejectService, SaveAutoRejectService>();
            services.AddScoped<ISaveVerifyMailingService, SaveVerifyMailingService>();
            services.AddScoped<IGetPendingByCodeService, GetPendingByCodeService>();
            services.AddScoped<IConditionNotApproveService, ConditionNotApproveService>();
            services.AddScoped<IVerifyCallService, VerifyCallService>();
            services.AddScoped<IVerifyRankForCheckOL7Service, VerifyRankForCheckOL7Service>();
            services.AddScoped<ICheckBranchBarcodeService, CheckBranchBarcodeService>();
            services.AddScoped<ICheckBranchForBarcodeService, CheckBranchForBarcodeService>();
            services.AddScoped<ICheckVerifyCallByJudgmentService, CheckVerifyCallByJudgmentService>();
            services.AddScoped<ICheckTabJudgmentService, CheckTabJudgmentService>();
            services.AddScoped<ICheckTabJudgmentService, CheckTabJudgmentService>();
            services.AddScoped<ISkipAutoRejectService, SkipAutoRejectService>();
            services.AddScoped<ICheckBirthDateRLService, CheckBirthDateRLService>();
            services.AddScoped<ICheckBarcodeService, CheckBarcodeService>();
            services.AddScoped<ICustomerViewService, CustomerViewService>();
            services.AddScoped<ICustomerEBCardService, CustomerEBCardService>();
            services.AddScoped<IGetCustomerDateTimeKeyInStep1Service, GetCustomerDateTimeKeyInStep1Service>();
            services.AddScoped<ISavePendingApplicationService, SavePendingApplicationService>();
            services.AddScoped<IApplicationDetailHistoryService, ApplicationDetailHistoryService>();
            services.AddScoped<IGetApplicationDataForJudgmentService, GetApplicationDataForJudgmentService>();
            services.AddScoped<ISaveApplicationExtendVendorService, SaveApplicationExtendVendorService>();
            services.AddScoped<ISaveLogTimeByJudgmentService, SaveLogTimeByJudgmentService>();
            services.AddScoped<IModifyApplicationDataByUSTP2JudgmentService, ModifyApplicationDataByUSTP2JudgmentService>();
            services.AddScoped<IModifyApplicationDataByUPDATEJudgmentService, ModifyApplicationDataByUPDATEJudgmentService>();
            services.AddScoped<IGetPendingCodeService, GetPendingCodeService>();
            services.AddScoped<ISendSmsImmediatelyService, SendSmsImmediatelyService>();
            services.AddScoped<IVerifyTEService, VerifyTEService>();
            services.AddScoped<IVerifyTEListService, VerifyTEListService>();
            services.AddScoped<IVerifyTOService, VerifyTOService>();
            services.AddScoped<IVerifyTRService, VerifyTRService>();
            services.AddScoped<IVerifyTHService, VerifyTHService>();
            services.AddScoped<IVerifyTMService, VerifyTMService>();
            services.AddScoped<ICheckCreditCriteriaService, CheckCreditCriteriaService>();
            services.AddScoped<ISaveSendDocumentCompleteService, SaveSendDocumentCompleteService>();
            services.AddScoped<ISaveApplicationLogTimeHistorySaveSendCaseService, SaveApplicationLogTimeHistorySaveSendCaseService>();
            services.AddScoped<ISaveApplicationExtendSendCaseMobileService, SaveApplicationExtendSendCaseMobileService>();
            services.AddScoped<ISaveRLSendCaseService, SaveRLSendCaseService>();
            services.AddScoped<ISaveReturnCaseService, SaveReturnCaseService>();
            services.AddScoped<IDetailInterviewApproveService, DetailInterviewApproveService>();
            services.AddScoped<IPaymentDueAutoService, PaymentDueAutoService>();
            services.AddScoped<ILoanTypeService, LoanTypeService>();
            services.AddScoped<ITransferDaysService, TransferDaysService>();
            services.AddScoped<IDataAfterSaveJudgmentService, DataAfterSaveJudgmentService>();
            services.AddScoped<IHubBranchService, HubBranchService>();
            services.AddScoped<ISendSmsDetailService, SendSmsDetailService>();
            services.AddScoped<ICutOffDateService, CutOffDateService>();
            services.AddScoped<ISaveSendSmsDetailVirtualBranchService, SaveSendSmsDetailVirtualBranchService>();
            services.AddScoped<ICheckAutoRejectForVerifyKeyInStep2Service, CheckAutoRejectForVerifyKeyInStep2Service>();
            services.AddScoped<ICheckApplicationForVerifyKeyInStep2Service, CheckApplicationForVerifyKeyInStep2Service>();
            services.AddScoped<IGetRequireFlagForCheckVerifyCallEntryMicroService, GetRequireFlagForCheckVerifyCallEntryMicroService>();
            services.AddScoped<IGetVerifyCodeForCheckVerifyCallEntryMicroService, GetVerifyCodeForCheckVerifyCallEntryMicroService>();
            services.AddScoped<ICheckVerifyCallEntryMicroService, CheckVerifyCallEntryMicroService>();
            services.AddScoped<ISaveSendSmsDetailSendSmsService, SaveSendSmsDetailSendSmsService>();
            services.AddScoped<ISaveSendSmsDetailBranchCounterService, SaveSendSmsDetailBranchCounterService>();
            services.AddScoped<IVerifyItemService, VerifyItemService>();
            services.AddScoped<IVerifyParameterService, VerifyParameterService>();
            services.AddScoped<IVerifyParameterListService, VerifyParameterListService>();
            services.AddScoped<IVerifyCustomerTypeService, VerifyCustomerTypeService>();
            services.AddScoped<IVerifyParameterInfoService, VerifyParameterInfoService>();
            services.AddScoped<IVerifyConfigService, VerifyConfigService>();
            services.AddScoped<ISetSendSmsDetailSendSmsService, SetSendSmsDetailSendSmsService>();
            services.AddScoped<ISaveSendSmsRejectApplicationService, SaveSendSmsRejectApplicationService>();
            services.AddScoped<ISendSmsRejectApplicationService, SendSmsRejectApplicationService>();
            services.AddScoped<ICheckApplicationAlreadyApproveRejectCancelService, CheckApplicationAlreadyApproveRejectCancelService>();
            services.AddScoped<IJudgmentService, JudgmentService>();
            services.AddScoped<IGetMessagesSendSmsService, GetMessagesSendSmsService>();
            services.AddScoped<ILockRecordService, LockRecordService>();
            services.AddScoped<ISendSmsRealTimeService, SendSmsRealTimeService>();
            services.AddScoped<ICheckInfoForCalculateKeyInStep2JudgmentTCLService, CheckInfoForCalculateKeyInStep2JudgmentTCLService>();
            services.AddScoped<ISendSmsKeyInStep1Service, SendSmsKeyInStep1Service>();
            services.AddScoped<IUnLockRecordPendingService, UnLockRecordPendingService>();
            services.AddScoped<ISendSmsForKeyInStep1Service, SendSmsForKeyInStep1Service>();
            services.AddScoped<IGetInquiryStepService, GetInquiryStepService>();
            services.AddScoped<ICheckLoanTypeForCalculateKeyInStep2Service, CheckLoanTypeForCalculateKeyInStep2Service>();
            services.AddScoped<ICalculateTclRclForKeyInStep2Service, CalculateTclRclForKeyInStep2Service>();
            services.AddScoped<IGetInquiryPendingService, GetInquiryPendingService>();
            services.AddScoped<IAllocatePerformanceBranchService, AllocatePerformanceBranchService>();
            services.AddScoped<IAllocateCService, AllocateCService>();
            services.AddScoped<IOfficeZipcodeService, OfficeZipcodeService>();
            services.AddScoped<IAllocateService, AllocateService>();
            services.AddScoped<INoAllocateService, NoAllocateService>();
            services.AddScoped<IPerformanceBranchAllocationService, PerformanceBranchAllocationService>();
            services.AddScoped<IGetListPendingCodeService, GetListPendingCodeService>();
            services.AddScoped<IGetControlDateByBusinessService, GetControlDateByBusinessService>();
            services.AddScoped<IGetMarketingDataService, GetMarketingDataService>();
            services.AddScoped<IDocumentRunningNoService, DocumentRunningNoService>();
            services.AddScoped<IFindDocumentSequentService, FindDocumentSequentService>();
            services.AddScoped<ICalculateLoanTypeService, CalculateLoanTypeService>();
            services.AddScoped<IGenerateContractNoService, GenerateContractNoService>();
            services.AddScoped<ICheckCriteriaSpecialCampaignService, CheckCriteriaSpecialCampaignService>();
            services.AddScoped<IGenerateReceiptNoService, GenerateReceiptNoService>();
            services.AddScoped<IFindReceiptNoTaxNoService, FindReceiptNoTaxNoService>();
            services.AddScoped<ICheckBirthDateRL1Service, CheckBirthDateRL1Service>();
            services.AddScoped<ILoadDataCustomerJudgmentService, LoadDataCustomerJudgmentService>();
            services.AddScoped<IGetRLTeamByBranchCodeLevelCodeControlDateService, GetRLTeamByBranchCodeLevelCodeControlDateService>();
            services.AddScoped<ILoadDataJudgmentService, LoadDataJudgmentService>();
            services.AddScoped<IManageWorkProcessService, CachedManageWorkProcessService>();
            services.AddScoped<IManageWorkProcessService, ManageWorkProcessService>();
            services.AddScoped<ManageWorkProcessService>();
            services.AddScoped<ILoadChangePriorityParameterService, LoadChangePriorityParameterService>();
            services.AddScoped<IManageTeamParameterService, ManageTeamParameterService>();
            services.AddScoped<IManageTeamLoadDataRLTeamService, ManageTeamLoadDataRLTeamService>();
            services.AddScoped<ISaveManageRLTeamService, SaveManageRLTeamService>();
            services.AddScoped<ISetCheckingKessaiToStep2Service, SetCheckingKessaiToStep2Service>();
            services.AddScoped<IManageProcessParameterService, ManageProcessParameterService>();
            services.AddScoped<ISetChecking2ConfirmService, SetChecking2ConfirmService>();
            services.AddScoped<ISaveManageWorkProcessUserService, SaveManageWorkProcessService>();
            //services.AddScoped<IGetDataChecking2Service, GetDataChecking2Service>();
            //services.AddScoped<ILoadCheckingAllDataService, LoadCheckingAllDataService>();
            services.AddScoped<ISaveDocumentTypeService, SaveDocumentTypeService>();
            services.AddScoped<ISaveApplicationService, SaveApplicationService>();
            services.AddScoped<ICheckInfoForCalculateKeyInStep2JudgmentTCLService, CheckInfoForCalculateKeyInStep2JudgmentTCLService>();
            services.AddScoped<IVerifyInterviewApproveService, VerifyInterviewApproveService>();
            services.AddScoped<ISaveLogTimeBySaveInterviewApproveService, SaveLogTimeBySaveInterviewApproveService>();
            services.AddScoped<IFindCampaignCreditCriteriaAfterCalculateTCLService, FindCampaignCreditCriteriaAfterCalculateTCLService>();
            services.AddScoped<ISaveConfirmationService, SaveConfirmationService>();
            services.AddScoped<IPreCheckService, PreCheckService>();
            services.AddScoped<IVerifyCallHistoryService, VerifyCallHistoryService>();
            services.AddScoped<IRunSaveReturnCaseStep2Service, RunSaveReturnCaseStep2Service>();
            services.AddScoped<ISaveReturnCaseStep2Service, SaveReturnCaseStep2Service>();
            services.AddScoped<IUpdateRLContractService, UpdateRLContractService>();
            services.AddScoped<IGetApplicationDataForSaveJudgmentConfirmationService, GetApplicationDataForSaveJudgmentConfirmationService>();
            services.AddScoped<IResultCreditBureauService, ResultCreditBureauService>();
            services.AddScoped<ISaveCreditBureauResultService, SaveCreditBureauResultService>();
            services.AddScoped<IVerifyKeyInStep1MobileStaffService, VerifyKeyInStep1MobileStaffService>();
            services.AddScoped<IUpdateUserKessaiService, UpdateUserKessaiService>();
            services.AddScoped<IGetUnlockRecordService, GetUnlockRecordService>();
            services.AddScoped<ISendSMSApproveService, SendSMSApproveService>();
            services.AddScoped<IGetInquiryCampaignService, GetInquiryCampaignService>();
            services.AddScoped<IGetApplicationPDFService, GetApplicationPDFService>();
            services.AddScoped<IDeletePendingVerifyCallService, DeletePendingVerifyCallService>();
            services.AddScoped<ICheckVerifyCallService, CheckVerifyCallService>();
            services.AddScoped<IPendingNoteService, PendingNoteService>();
            services.AddScoped<ICheckApplicationTypeInquiryStepService, CheckApplicationTypeInquiryStepService>();
            services.AddScoped<ICheckCardInquiryStepService, CheckCardInquiryStepService>();
            services.AddScoped<IGetListPendingService, GetListPendingService>();
            services.AddScoped<ISetUserKessaiForChangePriorityService, SetUserKessaiForChangePriorityService>();
            services.AddScoped<IGetListApplicationPendingService, GetListApplicationPendingService>();
            services.AddScoped<IGetListApplicationByBotenService, GetListApplicationByBotenService>();
            services.AddScoped<ISaveChangeKessaiService, SaveChangeKessaiService>();
            services.AddScoped<IGetInquiryPendingNewService, GetInquiryPendingNewService>();
            services.AddScoped<IGetInquiryStepNewService, GetInquiryStepNewService>();
            services.AddScoped<IGetUserJDByEmployeeIDService, GetUserJDByEmployeeIDService>();
            services.AddScoped<IGetCampaignIntroduceService, GetCampaignIntroduceService>();
            services.AddScoped<ICalJudgmentTCLService, CalJudgmentTCLService>();
            services.AddScoped<ISaveCalJudgmentTCLService, SaveCalJudgmentTCLService>();
            services.AddScoped<IRPT_SendCaseOCService, RPT_SendCaseOCService>();
            services.AddScoped<IGetBotenService, GetBotenService>();
            services.AddScoped<IGetBranchOCService, GetBranchOCService>();
            services.AddScoped<IGetListTeamSectionUserService, GetListTeamSectionUserService>();
            services.AddScoped<IGetInquiryApplicationService, GetInquiryApplicationService>();
            services.AddScoped<IVerifyEmergencyListService, VerifyEmergencyListService>();
            services.AddScoped<IUpdateApplicationMigrateService, UpdateApplicationMigrateService>();
            services.AddScoped<ICardTypeService, CardTypeService>();
            services.AddScoped<ISendSMSFirstLoanService, SendSMSFirstLoanService>();
            services.AddScoped<ISendSMSUploadDocService, SendSMSUploadDocService>();
            // MicroServices
            services.AddScoped<ILoadDataCheckOfficeMicroService, LoadDataCheckOfficeMicroService>();
            services.AddScoped<ISaveApplicationRejectAutoRejectMicroService, SaveApplicationRejectAutoRejectMicroService>();
            services.AddScoped<ISaveAutoRejectCancelCaseMicroService, SaveAutoRejectCancelCaseMicroService>();
            services.AddScoped<ICheckMinimumSalaryMicroService, CheckMinimumSalaryMicroService>();
            services.AddScoped<IUnLockRecordMicroService, UnLockRecordMicroService>();
            services.AddScoped<ISaveAutoRejectRejectCaseMicroService, SaveAutoRejectRejectCaseMicroService>();
            services.AddScoped<IVerifyKeyInStep1MicroService, VerifyKeyInStep1MicroService>();
            services.AddScoped<ISaveAutoRejectMicroService, SaveAutoRejectMicroService>();
            services.AddScoped<ISaveVerifyMailingMicroService, SaveVerifyMailingMicroService>();
            services.AddScoped<IGetPendingByCodeMicroService, GetPendingByCodeMicroService>();
            services.AddScoped<IPrepareDataForVerifyKeyInStep2MicroService, PrepareDataForVerifyKeyInStep2MicroService>();
            services.AddScoped<IVerifyRankForCheckOL7MicroService, VerifyRankForCheckOL7MicroService>();
            services.AddScoped<ICheckBranchBarcodeMicroService, CheckBranchBarcodeMicroService>();
            services.AddScoped<ICheckBranchForBarcodeMicroService, CheckBranchForBarcodeMicroService>();
            services.AddScoped<ICheckVerifyCallByJudgmentMicroService, CheckVerifyCallByJudgmentMicroService>();
            services.AddScoped<ICheckTabJudgmentMicroService, CheckTabJudgmentMicroService>();
            services.AddScoped<ICheckBirthDateRLMicroService, CheckBirthDateRLMicroService>();
            services.AddScoped<ICheckBarcodeMicroService, CheckBarcodeMicroService>();
            services.AddScoped<ICustomerViewMicroService, CustomerViewMicroService>();
            services.AddScoped<ICustomerEBCardMicroService, CustomerEBCardMicroService>();
            services.AddScoped<IGetCustomerDateTimeKeyInStep1MicroService, GetCustomerDateTimeKeyInStep1MicroService>();
            services.AddScoped<ISavePendingApplicationMicroService, SavePendingApplicationMicroService>();
            services.AddScoped<IGetApplicationDataForJudgmentMicroService, GetApplicationDataForJudgmentMicroService>();
            services.AddScoped<ISaveApplicationExtendVendorMicroService, SaveApplicationExtendVendorMicroService>();
            services.AddScoped<ISaveLogTimeByJudgmentMicroService, SaveLogTimeByJudgmentMicroService>();
            services.AddScoped<IModifyApplicationDataByUSTP2JudgmentMicroService, ModifyApplicationDataByUSTP2JudgmentMicroService>();
            services.AddScoped<IModifyApplicationDataByUPDATEJudgmentMicroService, ModifyApplicationDataByUPDATEJudgmentMicroService>();
            services.AddScoped<IGetPendingCodeMicroService, GetPendingCodeMicroService>();
            services.AddScoped<ISendSmsImmediatelyMicroService, SendSmsImmediatelyMicroService>();
            services.AddScoped<ICheckCreditCriteriaMicroService, CheckCreditCriteriaMicroService>();
            services.AddScoped<ISaveSendDocumentCompleteMicroService, SaveSendDocumentCompleteMicroService>();
            services.AddScoped<ISaveApplicationLogTimeHistorySaveSendCaseMicroService, SaveApplicationLogTimeHistorySaveSendCaseMicroService>();
            services.AddScoped<ISaveApplicationExtendSendCaseMobileMicroService, SaveApplicationExtendSendCaseMobileMicroService>();
            services.AddScoped<ISaveRLSendCaseMicroService, SaveRLSendCaseMicroService>();
            services.AddScoped<IDetailInterviewApproveMicroService, DetailInterviewApproveMicroService>();
            services.AddScoped<IDataAfterSaveJudgmentMicroService, DataAfterSaveJudgmentMicroService>();
            services.AddScoped<ISaveSendSmsDetailVirtualBranchMicroService, SaveSendSmsDetailVirtualBranchMicroService>();
            services.AddScoped<ICheckAutoRejectForVerifyKeyInStep2MicroService, CheckAutoRejectForVerifyKeyInStep2MicroService>();
            services.AddScoped<ICheckApplicationForVerifyKeyInStep2MicroService, CheckApplicationForVerifyKeyInStep2MicroService>();
            services.AddScoped<IGetRequireFlagForCheckVerifyCallEntryService, GetRequireFlagForCheckVerifyCallEntryService>();
            services.AddScoped<IGetVerifyCodeForCheckVerifyCallEntryService, GetVerifyCodeForCheckVerifyCallEntryService>();
            services.AddScoped<ICheckVerifyCallEntryService, CheckVerifyCallEntryService>();
            services.AddScoped<ISaveSendSmsDetailSendSmsMicroService, SaveSendSmsDetailSendSmsMicroService>();
            services.AddScoped<ISaveSendSmsDetailBranchCounterMicroService, SaveSendSmsDetailBranchCounterMicroService>();
            services.AddScoped<IVerifyParameterInfoMicroService, VerifyParameterInfoMicroService>();
            services.AddScoped<ISetSendSmsDetailSendSmsMicroService, SetSendSmsDetailSendSmsMicroService>();
            services.AddScoped<ISaveReturnCaseMicroService, SaveReturnCaseMicroService>();
            services.AddScoped<ISaveSendSmsRejectApplicationMicroService, SaveSendSmsRejectApplicationMicroService>();
            services.AddScoped<ISendSmsRejectApplicationMicroService, SendSmsRejectApplicationMicroService>();
            services.AddScoped<ICheckApplicationAlreadyApproveRejectCancelMicroService, CheckApplicationAlreadyApproveRejectCancelMicroService>();
            services.AddScoped<ILockRecordMicroService, LockRecordMicroService>();
            services.AddScoped<IGetApplicationDataForSaveInterviewApproveService, GetApplicationDataForSaveInterviewApproveService>();
            services.AddScoped<IJudgmentMicroService, JudgmentMicroService>();
            services.AddScoped<IGetMessagesSendSmsMicroService, GetMessagesSendSmsMicroService>();
            services.AddScoped<ISendSmsRealTimeMicroService, SendSmsRealTimeMicroService>();
            services.AddScoped<ICheckInfoForCalculateKeyInStep2JudgmentTCLMicroService, CheckInfoForCalculateKeyInStep2JudgmentTCLMicroService>();
            services.AddScoped<ISendSmsKeyInStep1MicroService, SendSmsKeyInStep1MicroService>();
            services.AddScoped<IUnLockRecordPendingMicroService, UnLockRecordPendingMicroService>();
            services.AddScoped<ISendSmsForKeyInStep1MicroService, SendSmsForKeyInStep1MicroService>();
            services.AddScoped<IGetInquiryStepMicroService, GetInquiryStepMicroService>();
            services.AddScoped<ICheckLoanTypeForCalculateKeyInStep2MicroService, CheckLoanTypeForCalculateKeyInStep2MicroService>();
            services.AddScoped<ICalculateTclRclForKeyInStep2MicroService, CalculateTclRclForKeyInStep2MicroService>();
            services.AddScoped<IGetInquiryPendingMicroService, GetInquiryPendingMicroService>();
            services.AddScoped<IAllocateCMicroService, AllocateCMicroService>();
            services.AddScoped<IAllocateMicroService, AllocateMicroService>();
            services.AddScoped<INoAllocateMicroService, NoAllocateMicroService>();
            services.AddScoped<IPerformanceBranchAllocationMicroService, PerformanceBranchAllocationMicroService>();
            services.AddScoped<IGetListPendingCodeMicroService, GetListPendingCodeMicroService>();
            services.AddScoped<IGetControlDateByBusinessMicroService, GetControlDateByBusinessMicroService>();
            services.AddScoped<IGetMarketingDataMicroService, GetMarketingDataMicroService>();
            services.AddScoped<IFindDocumentSequentMicroService, FindDocumentSequentMicroService>();
            services.AddScoped<ICalculateLoanTypeMicroService, CalculateLoanTypeMicroService>();
            services.AddScoped<IGenerateContractNoMicroService, GenerateContractNoMicroService>();
            services.AddScoped<ICheckCriteriaSpecialCampaignMicroService, CheckCriteriaSpecialCampaignMicroService>();
            services.AddScoped<IGenerateReceiptNoMicroService, GenerateReceiptNoMicroService>();
            services.AddScoped<IFindReceiptNoTaxNoMicroService, FindReceiptNoTaxNoMicroService>();
            services.AddScoped<ICheckBirthDateRL1MicroService, CheckBirthDateRL1MicroService>();
            services.AddScoped<ILoadDataCustomerJudgmentMicroService, LoadDataCustomerJudgmentMicroService>();
            services.AddScoped<IGetRLTeamByBranchCodeLevelCodeControlDateMicroService, GetRLTeamByBranchCodeLevelCodeControlDateMicroService>();
            services.AddScoped<ILoadDataJudgmentMicroService, LoadDataJudgmentMicroService>();
            services.AddScoped<IGetApplicationDataForSaveInterviewApproveMicroService, GetApplicationDataForSaveInterviewApproveMicroService>();
            services.AddScoped<ILoadChangePriorityParameterServiceMicroService, LoadChangePriorityParameterServiceMicroService>();
            services.AddScoped<IManageWorkProcessServiceMicroService, ManageWorkProcessServiceMicroService>();
            services.AddScoped<IManageTeamParameterServiceMicroService, ManageTeamParameterServiceMicroService>();
            services.AddScoped<IManageTeamLoadDataRLTeamServiceMicroService, ManageTeamLoadDataRLTeamServiceMicroService>();
            services.AddScoped<ISaveManageRLTeamServiceMicroService, SaveManageRLTeamServiceMicroService>();
            services.AddScoped<ISetManageRLTeamServiceMicroService, SetManageRLTeamServiceMicroService>();
            services.AddScoped<ISetCheckingKessaiToStep2ServiceMicroService, SetCheckingKessaiToStep2ServiceMicroService>();
            services.AddScoped<IManageWorkProcessParameterServiceMicroService, ManageWorkProcessParameterServiceMicroService>();
            services.AddScoped<ISetChecking2ConfirmMicroService, SetChecking2ConfirmMicroService>();
            services.AddScoped<ISaveManageWorkProcessServiceMicroService, SaveManageWorkProcessUserServiceMicroService>();
            //services.AddScoped<IGetDataChecking2ServiceMicroService, GetDataChecking2ServiceMicroService>();
            //services.AddScoped<ILoadCheckingAllDataServiceMicroService, LoadCheckingAllDataServiceMicroService>();
            services.AddScoped<ISaveDocumentTypeServiceMicroService, SaveDocumentTypeServiceMicroService>();
            services.AddScoped<IGetApplicationDataForSaveInterviewApproveMicroService, GetApplicationDataForSaveInterviewApproveMicroService>();
            services.AddScoped<ISaveApplicationMicroService, SaveApplicationMicroService>();
            services.AddScoped<ICheckInfoForCalculateKeyInStep2JudgmentTCLMicroService, CheckInfoForCalculateKeyInStep2JudgmentTCLMicroService>();
            services.AddScoped<IVerifyInterviewApproveMicroService, VerifyInterviewApproveMicroService>();
            services.AddScoped<ISaveLogTimeBySaveInterviewApproveMicroService, SaveLogTimeBySaveInterviewApproveMicroService>();
            services.AddScoped<IFindCampaignCreditCriteriaAfterCalculateTCLMicroService, FindCampaignCreditCriteriaAfterCalculateTCLMicroService>();
            services.AddScoped<ISaveConfirmationMicroService, SaveConfirmationMicroService>();
            services.AddScoped<IRunSaveReturnCaseStep2MicroService, RunSaveReturnCaseStep2MicroService>();
            services.AddScoped<ISaveReturnCaseStep2MicroService, SaveReturnCaseStep2MicroService>();
            services.AddScoped<IUpdateRLContractMicroService, UpdateRLContractMicroService>();
            services.AddScoped<IGetApplicationDataForSaveJudgmentConfirmationMicroService, GetApplicationDataForSaveJudgmentConfirmationMicroService>();
            services.AddScoped<ISaveCreditBureauResultMicroService, SaveCreditBureauResultMicroService>();
            services.AddScoped<IVerifyKeyInStep1MobileStaffMicroService, VerifyKeyInStep1MobileStaffMicroService>();
            services.AddScoped<IUpdateUserKessaiMicroService, UpdateUserKessaiMicroService>();
            services.AddScoped<IGetUnlockRecordMicroService, GetUnlockRecordMicroService>();
            services.AddScoped<ISendSMSApproveMicroService, SendSMSApproveMicroService>();
            services.AddScoped<IGetInquiryCampaignMicroService, GeInquiryCampaignMicroService>();
            services.AddScoped<IGetApplicationPDFMicroService, GetApplicationPDFMicroService>();
            services.AddScoped<IDeletePendingVerifyCallMicroService, DeletePendingVerifyCallMicroService>();
            services.AddScoped<ICheckVerifyCallMicroService, CheckVerifyCallMicroService>();
            services.AddScoped<IPendingNoteMicroService, PendingNoteMicroService>();
            services.AddScoped<ICheckApplicationTypeInquiryStepMicroService, CheckApplicationTypeInquiryStepMicroService>();
            services.AddScoped<ICheckCardInquiryStepMicroService, CheckCardInquiryStepMicroService>();
            services.AddScoped<IGetListPendingMicroService, GetListPendingMicroService>();
            services.AddScoped<ISetUserKessaiForChangePriorityMicroService, SetUserKessaiForChangePriorityMicroService>();
            services.AddScoped<IGetListApplicationPendingMicroService, GetListApplicationPendingMicroService>();
            services.AddScoped<IGetListApplicationByBotenMicroService, GetListApplicationByBotenMicroService>();
            services.AddScoped<ISaveChangeKessaiMicroService, SaveChangeKessaiMicroService>();
            services.AddScoped<IGetInquiryPendingNewMicroService, GetInquiryPendingNewMicroService>();
            services.AddScoped<IGetInquiryStepNewMicroService, GetInquiryStepNewMicroService>();
            services.AddScoped<IGetUserJDByEmployeeIDMicroService, GetUserJDByEmployeeIDMicroService>();
            services.AddScoped<IGetCampaignIntroduceMicroService, GetCampaignIntroduceMicroService>();
            services.AddScoped<ISaveCalJudgmentTCLMicroService, SaveCalJudgmentTCLMicroService>();
            services.AddScoped<IRPT_SendCaseOCMicroService, RPT_SendCaseOCMicroService>();
            services.AddScoped<IGetBotenMicroService, GetBotenMicroService>();
            services.AddScoped<IGetBranchOCMicroService, GetBranchOCMicroService>();
            services.AddScoped<IGetListTeamSectionUserMicroService, GetListTeamSectionUserMicroService>();
            services.AddScoped<IGetInquiryApplicationMicroService, GetInquiryApplicationMicroService>();
            services.AddScoped<IUpdateApplicationMigrateMicroService, UpdateApplicationMigrateMicroService>();
            services.AddScoped<IApplicationPendingSMSService, ApplicationPendingSMSService>();
            services.AddScoped<ISendSmsPendingMicroService, SendSmsPendingMicroService>();
            services.AddScoped<ICustomerMssqlMicroService, CustomerMssqlMicroService>();
            services.AddScoped<ISendSmsCenterMicroService, SendSmsCenterMicroService>();
            services.AddScoped<ISendSMSFirstLoanMicroService, SendSMSFirstLoanMicroService>();
            services.AddScoped<ISendSMSUploadDocMicroService, SendSMSUploadDocMicroService>();
            services.AddScoped<ISaveAutoRejectViewCustomerService, SaveAutoRejectViewCustomerService>();
            services.AddScoped<ISaveAutoRejectViewCustomerMicroService, SaveAutoRejectViewCustomerMicroService>();
            services.AddScoped<IRLPublisherAPIMicroService, RLPublisherAPIMicroService>();
            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_1);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseHsts();
            }

            app.UseRouter(RouterTransaction.BuildRouter(app));
            app.UseAuthentication();
            app.UseCors("CorsPolicy");

            if (this._useMiddleware)
            {
                app.UseMiddleware<GCMiddleware>();
                app.UseMiddleware<LoggingMiddleware>("RLAPI");
            }

            app.UseMvc();

        }
    }

    public static class AppsettingConfigs
    {
        public static IConfiguration config { get; set; }
    }
}
