﻿using Newtonsoft.Json;
using System.Collections;
using System.Collections.Generic;

namespace System.Linq
{
    static public class EntitesExtension
    {
        static public List<T> MapValue<T>(this IQueryable _iQuery)
        {
            JsonSerializerSettings settings = new JsonSerializerSettings
            {
                NullValueHandling = NullValueHandling.Ignore,
                MissingMemberHandling = MissingMemberHandling.Ignore,
                Formatting = Formatting.None,
                DateFormatHandling = DateFormatHandling.IsoDateFormat
            };

            string json = JsonConvert.SerializeObject(_iQuery, settings);
            return JsonConvert.DeserializeObject<List<T>>(json);
        }

        static public List<T> MapValue<T>(this IEnumerable _iQuery)
        {
          
            JsonSerializerSettings settings = new JsonSerializerSettings
            {
                NullValueHandling = NullValueHandling.Ignore,
                MissingMemberHandling = MissingMemberHandling.Ignore,
                Formatting = Formatting.None,
                DateFormatHandling = DateFormatHandling.IsoDateFormat
            };

            string json = JsonConvert.SerializeObject(_iQuery, settings);
            return JsonConvert.DeserializeObject<List<T>>(json);
        }

        static public bool IsEmpty(this IList _iQuery)
        {
            if (_iQuery == null)
            {
                return true;
            }
            else
            {
                if (_iQuery.Count > 0)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }
    }
}
