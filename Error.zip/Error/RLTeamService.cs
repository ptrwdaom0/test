﻿using System;
using System.Linq;
using System.Collections.Generic;
using Microsoft.Extensions.Options;
using Easybuy.WebApplication.Utility;
using Easybuy.WebApplication.Utility.Exceptions;
using Easybuy.WebApplication.Utility.Models;
using Easybuy.WebApplication.RLScreen.RLAPI.Services.Interfaces;
using Easybuy.WebApplication.RLScreen.RLAPI.DataAccess.RLAPIDb;
using Easybuy.WebApplication.RLScreen.RLAPI.Models.Get;
using Easybuy.WebApplication.RLScreen.RLAPI.Models.Post;
using Easybuy.WebApplication.RLScreen.RLAPI.Models.Put;
using Easybuy.WebApplication.RLScreen.RLAPI.Models.Business;

namespace Easybuy.WebApplication.RLScreen.RLAPI.Services
{
    public class RLTeamService : IRLTeamService
    {
        private readonly IOptions<MessageExceptionModel> _optsEx;
        private readonly IRLAPIUoW _rlAPIUoW;

        public RLTeamService(IRLAPIUoW rlAPIUoW, IOptions<MessageExceptionModel> optsEx)
        {
            this._rlAPIUoW = rlAPIUoW;
            this._optsEx = optsEx;
        }

        public GetRLTeamModel CheckExpireDateByUserName(string userName)
        {
            try
            {
                var _rLTeams = _rlAPIUoW.RLTeam;

                var rLTeams = (from a in _rLTeams
                               where a.userCode == userName
                                   && a.recordStatus == ""
                                   && (!string.IsNullOrWhiteSpace(a.processType)
                                   && !"0".Equals(a.processType))
                                   && a.effectiveDate <= DateTime.Now
                                   && (a.expireDate != null ? DateTime.Now <= a.expireDate : 1 == 1)
                               select a
                    ).MapValue<GetRLTeamModel>().FirstOrDefault();

                return rLTeams;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<GetRLTeamModel> GetTeamData(PostGetTeamDataModel data)
        {
            try
            {
                var _rLTeams = _rlAPIUoW.RLTeam;
                var _rlWorkProcess = _rlAPIUoW.WorkProcessUser;
                var rLTeamsData = (from a in _rLTeams
                                   join b in _rlWorkProcess
                on new { a = a.id }
                equals new { a = b.teamId } into c
                                   from d in c.Where(e => e.branchCode == data.branchCode
                                                        && e.sectionCode == data.sectionCode
                                                        && e.teamCode == data.teamCode
                                                        && e.recordStatus == ""
                                                        && (DateTime.Now >= e.startDate && DateTime.Now <= e.endDate)
                                                    ).DefaultIfEmpty()
                                   where a.branchCode == data.branchCode
                                   && a.sectionCode == data.sectionCode
                                   && a.teamCode == data.teamCode
                                   && a.expireDate >= DateTime.Now
                                   && a.recordStatus == ""
                                   select new GetRLTeamModel
                                   {
                                       id = a.id,
                                       branchCode = a.branchCode,
                                       sectionCode = a.sectionCode,
                                       teamCode = a.teamCode,
                                       userCode = a.userCode,
                                       effectiveDate = a.effectiveDate,
                                       expireDate = a.expireDate,
                                       remark = a.remark,
                                       levelCode = a.levelCode,
                                       processType = a.processType,
                                       processTypeAfter = d.processType.ToString(),
                                       recordStatus = a.recordStatus,
                                       workPrcessUserActive = d.recordStatus,
                                       createBy = a.createBy,
                                       createDate = a.createDate,
                                       updateBy = a.updateBy,
                                       updateDate = a.updateDate
                                   }).MapValue<GetRLTeamModel>();

                return rLTeamsData;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public GetRLTeamModel GetWorkProcess(PostGetWorkProcessModel data)
        {
            try
            {
                if (data != null)
                {
                    var _rLTeams = _rlAPIUoW.RLTeam;

                    var rLTeamsData = (from a in _rLTeams
                                   where a.sectionCode == data.sectionCode
                                       && a.teamCode == data.teamCode
                                       && a.recordStatus == ""
                                   select a
                        ).MapValue<GetRLTeamModel>().FirstOrDefault();

                    return rLTeamsData;
                }
                else
                {
                    return null;
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public List<GetRLTeamModel> GetListRLTeamByBranchCodeLevelCodeControlDate(string branchCode, string levelCode, DateTime? controlDate)
        {
            try
            {                
                if (controlDate == null)
                {
                    throw new Exception("ControlDate is not be NULL");
                }
                else
                {
                    DateTime ctrlDate = (DateTime)controlDate;

                    var _rLTeams = _rlAPIUoW.RLTeam;

                    var rLTeamsData = (from a in _rLTeams
                                    where a.branchCode == branchCode
                                        && a.levelCode == levelCode
                                        && (ctrlDate.Date >= ((DateTime)a.effectiveDate).Date && ctrlDate.Date <= ((DateTime)a.expireDate).Date)
                                        && a.recordStatus == ""
                                    select a
                        ).MapValue<GetRLTeamModel>();

                    return rLTeamsData;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<JoinGetTeamModel> GetRLTeamByUserCodeJDCode(string userCode, string jdCode)
        {
            try
            {
                List<JoinGetTeamModel> listTeam = null;
                var _rLTeams = _rlAPIUoW.RLTeam;
                var _team = _rlAPIUoW.Team;
                if (jdCode == "MG" || jdCode == "LD")
                {
                    listTeam = (from a in _rLTeams
                                join b in _team
                                on a.teamCode equals b.teamCode
                                where a.userCode == userCode
                                && a.recordStatus == ""
                                select new JoinGetTeamModel
                                {
                                    teamCode = a.teamCode,
                                    teamName = b.teamName
                                }).ToList<JoinGetTeamModel>();
                }

                return listTeam;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<GetRLTeamModel> GetRLTeamAllDataForSearch(PostGetTeamDataModel data)
        {
            try
            {
                string cur = DateTime.Now.ToString("yyyy-MM-dd");
                DateTime currentDate = DateTime.ParseExact(cur, "yyyy-MM-dd", null);

                var _rLTeams = _rlAPIUoW.RLTeam;
                var rLTeamsData = (from a in _rLTeams
                                   where a.branchCode == data.branchCode
                                       && a.sectionCode == data.sectionCode
                                       && a.teamCode == data.teamCode
                                       && a.recordStatus == ""
                                       && ((a.expireDate >= currentDate) || (a.expireDate == null))
                                   select a
                    ).MapValue<GetRLTeamModel>();

                return rLTeamsData;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<GetRLTeamModel> GetRLTeamByUserCode(string userCode)
        {
            try
            {
                var _rLTeams = _rlAPIUoW.RLTeam;
                var rLTeamsData = (from a in _rLTeams
                                   where a.recordStatus == ""
                                       && a.userCode == userCode
                                   select a
                    ).MapValue<GetRLTeamModel>();

                return rLTeamsData;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public ResultDbModel AddRLTeam(PostRLTeamModel data)
        {
            try
            {
                data.createDate = DateTime.Now;

                var rLTeamEntity = Common.MapValue<RLTeamEntity, PostRLTeamModel>(data);
                _rlAPIUoW.RLTeam.Add(rLTeamEntity);
                _rlAPIUoW.SaveChanges();

                ResultDbModel result = new ResultDbModel
                {
                    lastId = rLTeamEntity.id,
                    data = Common.MapValue<PostRLTeamModel, RLTeamEntity>(rLTeamEntity)
                };

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void AbortAddRLTeam(Int64 id)
        {
            try
            {
                var rLTeamEntities = _rlAPIUoW.RLTeam;
                var rlTeamOldData = (from a in rLTeamEntities
                                     where a.id == id && a.recordStatus == ""
                                     select a
                        ).FirstOrDefault();

                if (rlTeamOldData != null)
                {
                    _rlAPIUoW.RLTeam.Remove(rlTeamOldData);
                    _rlAPIUoW.SaveChanges();
                }
                else
                {
                    throw new ExceptionService(_optsEx, "E-247");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void SetRLTeam(Int64? id, PutRLTeamModel data)
        {
            try
            {
                var rLTeamEntities = _rlAPIUoW.RLTeam;
                var rlTeamOldData = (from x in rLTeamEntities
                                     where x.id.Equals(id)
                                     select x).FirstOrDefault();

                if (data == null)
                {
                    throw new ExceptionService(_optsEx, "E-247");
                }
                else
                {
                    rlTeamOldData.effectiveDate = data.effectiveDate;
                    rlTeamOldData.expireDate = data.expireDate;
                    rlTeamOldData.remark = data.remark;
                    rlTeamOldData.levelCode = data.levelCode;
                    rlTeamOldData.processType = data.processType;
                    rlTeamOldData.recordStatus = data.recordStatus;
                    rlTeamOldData.updateBy = data.updateBy;
                    rlTeamOldData.updateDate = DateTime.Now;

                    _rlAPIUoW.RLTeam.Update(rlTeamOldData);
                    _rlAPIUoW.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void AbortSetRLTeam(Int64 id, PutRLTeamModel data)
        {
            try
            {
                var rLTeamEntities = _rlAPIUoW.RLTeam;
                var rlTeamOldData = (from a in rLTeamEntities
                                     where a.id.Equals(id)
                                     select a).FirstOrDefault();

                if (rlTeamOldData != null)
                {
                    rlTeamOldData.effectiveDate = data.effectiveDate;
                    rlTeamOldData.expireDate = data.expireDate;
                    rlTeamOldData.remark = data.remark;
                    rlTeamOldData.levelCode = data.levelCode;
                    rlTeamOldData.processType = data.processType;
                    rlTeamOldData.recordStatus = data.recordStatus;
                    rlTeamOldData.updateBy = data.updateBy;
                    rlTeamOldData.updateDate = data.updateDate;

                    _rlAPIUoW.RLTeam.Update(rlTeamOldData);
                    _rlAPIUoW.SaveChanges();
                }
                else
                {
                    throw new ExceptionService(_optsEx, "E-247");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<GetRLTeamModel> GetRLTeamByBranchCodeTeamCode(string branchCode, string teamCode)
        {
            try
            {
                var _rLTeams = _rlAPIUoW.RLTeam;
                var rLTeamsData = (from a in _rLTeams
                                   where a.branchCode == branchCode
                                       && a.teamCode == teamCode
                                       && a.recordStatus == ""
                                   orderby a.userCode, a.expireDate descending
                                   select a
                    ).MapValue<GetRLTeamModel>();

                return rLTeamsData;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public GetRLTeamModel GetRLTeamByUserName(string userName)
        {
            try
            {
                var _rLTeams = _rlAPIUoW.RLTeam;

                var rLTeams = (from a in _rLTeams
                               where a.userCode == userName
                                   && a.recordStatus == ""
                               select a
                    ).MapValue<GetRLTeamModel>().FirstOrDefault();

                return rLTeams;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public GetRLTeamModel GetRLTeamById(int teamId)
        {
            var result = (from x in _rlAPIUoW.RLTeam
                          where x.id == teamId
                          select x).MapValue<GetRLTeamModel>();

            if (result.IsEmpty())
            {
                return null;
            }
            else
            {
                return result.FirstOrDefault();
            }
        }

        public List<GetRLTeamModel> GetListRLTeamByBranchCode(string branchCode, DateTime? controlDate)
        {
            try
            {
                if (controlDate == null)
                {
                    throw new Exception("ControlDate is not be NULL");
                }
                else
                {
                    DateTime ctrlDate = (DateTime)controlDate;

                    var _rLTeams = _rlAPIUoW.RLTeam;

                    var rLTeamsData = (from a in _rLTeams
                                       where a.branchCode == branchCode
                                           && (ctrlDate.Date >= ((DateTime)a.effectiveDate).Date && ctrlDate.Date <= ((DateTime)a.expireDate).Date)
                                           && a.recordStatus == ""
                                       select a
                        ).DistinctBy(x => new { x.branchCode, x.sectionCode, x.teamCode, x.userCode }).MapValue<GetRLTeamModel>();

                    return rLTeamsData;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
