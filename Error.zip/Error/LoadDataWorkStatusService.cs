﻿using System;
using Easybuy.WebApplication.Utility.Models;
using Microsoft.Extensions.Options;
using Easybuy.WebApplication.Utility.UserPrinciple;
using Easybuy.WebApplication.RLScreen.RLProcessAPI.Services.Interfaces;
using Easybuy.WebApplication.RLScreen.RLProcessAPI.Services.Interfaces.Microservices;
using Easybuy.WebApplication.RLScreen.RLProcessAPI.Models.Get;
using Easybuy.WebApplication.Utility;

namespace Easybuy.WebApplication.RLScreen.RLProcessAPI.Services
{
    public class LoadDataWorkStatusService : ILoadDataWorkStatusService
    {
        private readonly IOptions<MessageExceptionModel> _optsEx;

        private ICheckDataWorkProcessMicroService _ms;
        private IWorkProcessServiceMicroService _workProcess;

        private readonly UserPrinciple _userPrinciple;

        public LoadDataWorkStatusService(IOptions<MessageExceptionModel> optsEx, ICheckDataWorkProcessMicroService ms, IWorkProcessServiceMicroService workProcess = null)
        {
            _optsEx = optsEx;
            _ms = ms;
            _workProcess = workProcess;
        }

        public GetWorkStatusProcessModel loadDataWorkStatus(string userName)
        {
            GetWorkStatusProcessModel getWorkStatusProcessModel = null;
            try
            {
                GetRLTeamModel getRLTeamModel = _ms.CheckExpireDateByUserName(userName);

                if (getRLTeamModel != null)
                {
                    getWorkStatusProcessModel = new GetWorkStatusProcessModel();

                    //Develop_auto
                    //GetWorkProcessUserModel getWorkProcessUserModel = _ms.GetProcessTypeByUserName(userName);

                    GetWorkProcessUserModel getWorkProcessUserModel = _ms.GetProcessTypeByUserNameAndTeam(userName, getRLTeamModel.id.ToString());

                    if (getWorkProcessUserModel != null)
                    {

                        GetBranchModel getBranchModel = _ms.GetDescriptionBranchByBranchCode(getWorkProcessUserModel.branchCode);

                        if (getBranchModel != null)
                        {
                            getWorkStatusProcessModel = Common.MapValue<GetWorkStatusProcessModel, GetBranchModel>(getBranchModel);
                        }

                        GetProcessTypeModel getProcessTypeModel = _ms.GetDescriptonByProcessType(getWorkProcessUserModel.processType);

                        if (getProcessTypeModel != null)
                        {
                            if (getWorkStatusProcessModel == null)
                            {
                                getWorkStatusProcessModel = new GetWorkStatusProcessModel();
                            }
                            getWorkStatusProcessModel.processType = getProcessTypeModel.processType;
                            getWorkStatusProcessModel.processTypeDesc = getProcessTypeModel.descriptionTh;
                            getWorkStatusProcessModel.userBranch = getWorkProcessUserModel.branchCode;
                            getWorkStatusProcessModel.userSection = getWorkProcessUserModel.sectionCode;
                            getWorkStatusProcessModel.userTeam = getWorkProcessUserModel.teamCode;
                            getWorkStatusProcessModel.levelCode = getRLTeamModel.levelCode;
                        }
                    }
                    else
                    {
                        GetBranchModel getBranchModel = _ms.GetDescriptionBranchByBranchCode(getRLTeamModel.branchCode);

                        if (getBranchModel != null)
                        {
                            getWorkStatusProcessModel = Common.MapValue<GetWorkStatusProcessModel, GetBranchModel>(getBranchModel);
                        }

                        GetProcessTypeModel getProcessTypeModel = _ms.GetDescriptonByProcessType(Int32.Parse(getRLTeamModel.processType));

                        if (getProcessTypeModel != null)
                        {
                            if (getWorkStatusProcessModel == null)
                            {
                                getWorkStatusProcessModel = new GetWorkStatusProcessModel();
                            }
                            getWorkStatusProcessModel.processType = getProcessTypeModel.processType;
                            getWorkStatusProcessModel.processTypeDesc = getProcessTypeModel.descriptionTh;
                            getWorkStatusProcessModel.userBranch = getRLTeamModel.branchCode;
                            getWorkStatusProcessModel.userSection = getRLTeamModel.sectionCode;
                            getWorkStatusProcessModel.userTeam = getRLTeamModel.teamCode;
                            getWorkStatusProcessModel.levelCode = getRLTeamModel.levelCode;
                        }
                    }
                }
                return getWorkStatusProcessModel;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }

}


