﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Easybuy.WebApplication.RLScreen.RLProcessAPI.Services.Interfaces;
using Easybuy.WebApplication.RLScreen.RLProcessAPI.Models.Get;

namespace RLScreen.RLProcessAPI.API
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class WorkProcessController : ControllerBase
    {
        private readonly ILoadDataWorkStatusService _loadDataWorkStatusService;
        public WorkProcessController(ILoadDataWorkStatusService loadDataWorkStatusService)
        {
            _loadDataWorkStatusService = loadDataWorkStatusService;
        }

        [Authorize]
        [HttpGet("{userName}", Name = "loadDataWorkStatus")]
        public GetWorkStatusProcessModel loadDataWorkStatus(string userName)
        {
            return _loadDataWorkStatusService.loadDataWorkStatus(userName);
        }

    }

}
